import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function archive(source,dest){
 const fd=fs.openSync(source,'r');let out;
 try{
  const prefix=Buffer.alloc(16);if(fs.readSync(fd,prefix,0,16,0)!==16)throw Error('程序包不完整');const n=prefix.readUInt32LE(12);if(n<2||n>64*1024*1024)throw Error('程序包格式不兼容');const raw=Buffer.alloc(n);if(fs.readSync(fd,raw,0,n,16)!==n)throw Error('程序包头不完整');const tree=JSON.parse(raw),base=8+prefix.readUInt32LE(4),items=[];
  function walk(node,p=''){for(const [name,e] of Object.entries(node.files||{})){const q=p+name;if(e.files)walk(e,q+'/');else if(e.offset!==undefined){const offset=Number(e.offset),size=Number(e.size);if(!Number.isSafeInteger(offset)||!Number.isSafeInteger(size)||offset<0||size<0)throw Error('程序包索引异常');items.push({path:q,e,offset,size});}}}walk(tree);items.sort((a,b)=>a.offset-b.offset);
  const find=name=>items.find(x=>x.path==='out/bundle/renderer/assets/'+name);for(const name of ['aks-cloud-device.js','hearing-CWm8WPGq.js','chat-DqklHny2.js'])if(!find(name))throw Error('程序版本不兼容，缺少 '+name);
  const item=find('aks-cloud-device.js'),previous=Buffer.alloc(item.size);if(fs.readSync(fd,previous,0,item.size,base+item.offset)!==item.size)throw Error('同步模块不完整');const prior=previous.toString('utf8');if(!prior.includes('aks-cloud')||!prior.includes('hearing-CWm8WPGq.js')||!prior.includes('chat-DqklHny2.js')||!(prior.includes('ensureBoundSession')||prior.includes('selectExistingCloudSession')))throw Error('同步模块版本不兼容，未进行修改');
  item.bytes=fs.readFileSync(path.join(dir,'aks-cloud-device.js'));item.e.size=item.bytes.length;const digest=hash(item.bytes);item.e.integrity={algorithm:'SHA256',hash:digest,blockSize:4194304,blocks:[digest]};
  let pos=0;for(const x of items){x.e.offset=String(pos);pos+=x.e.size}const json=Buffer.from(JSON.stringify(tree)),ps=Math.ceil((json.length+4)/4)*4,header=Buffer.alloc(4+ps);header.writeUInt32LE(ps,0);header.writeUInt32LE(json.length,4);json.copy(header,8);const size=Buffer.alloc(8);size.writeUInt32LE(4,0);size.writeUInt32LE(header.length,4);
  out=fs.openSync(dest,'wx');fs.writeSync(out,size);fs.writeSync(out,header);const buf=Buffer.alloc(8*1024*1024);for(const x of items){if(x.bytes){fs.writeSync(out,x.bytes);continue}for(let at=0;at<x.size;){const n=Math.min(buf.length,x.size-at);if(fs.readSync(fd,buf,0,n,base+x.offset+at)!==n)throw Error('程序包数据不完整');fs.writeSync(out,buf,0,n);at+=n}}fs.fsyncSync(out);fs.closeSync(out);out=undefined;
  const verify=fs.openSync(dest,'r');try{const b=Buffer.alloc(item.bytes.length);if(fs.readSync(verify,b,0,b.length,8+header.length+Number(item.e.offset))!==b.length||!b.equals(item.bytes))throw Error('写入校验失败')}finally{fs.closeSync(verify)}
 }finally{if(out!==undefined)fs.closeSync(out);fs.closeSync(fd)}
}
try{
 if(process.argv[2]==='--prepare'){archive(process.argv[3],process.argv[4]);console.log('PREPARED');process.exit(0)}
 const root=process.argv[2];if(!root)throw Error('没有找到安装目录');const source=path.join(root,'airi','resources','app.asar');if(!fs.existsSync(source)||!fs.existsSync(path.join(root,'client','device-server.mjs')))throw Error('安装目录不完整');
 const processes=spawnSync('tasklist',['/FI','IMAGENAME eq airi.exe','/FO','CSV','/NH'],{encoding:'utf8'});if(processes.error||processes.status!==0)throw Error('无法确认小 A 是否关闭，请重试');if(/"airi\.exe"/i.test(processes.stdout))throw Error('请先完全退出小 A，再运行更新');
 const stat=fs.statfsSync(path.dirname(source));if(stat.bavail*stat.bsize<fs.statSync(source).size*2+50*1024*1024)throw Error('磁盘空间不足，请至少留出两个程序包大小的空间');
 const stamp=new Date().toISOString().replace(/[:.]/g,'-'),temp=source+'.sync-update-'+stamp+'.tmp',backup=source+'.before-sync-update-'+stamp+'.bak';let moved=false;
 try{archive(source,temp);fs.renameSync(source,backup);moved=true;fs.renameSync(temp,source)}catch(e){if(moved&&!fs.existsSync(source)&&fs.existsSync(backup))fs.renameSync(backup,source);if(fs.existsSync(temp))fs.unlinkSync(temp);throw e}
 console.log('更新完成。原程序备份：'+backup);console.log('请通过原来的启动入口打开小 A，并保持原有云端登录。');
}catch(e){console.error('未完成：'+e.message);process.exitCode=1}
