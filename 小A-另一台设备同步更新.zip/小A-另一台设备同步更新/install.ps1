$ErrorActionPreference = 'Stop'
try {
  [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
  Write-Host '小 A 同步更新：请先彻底退出小 A。'
  $candidates = @(Get-ChildItem -LiteralPath ([Environment]::GetFolderPath('MyDocuments')) -Directory -ErrorAction SilentlyContinue | Where-Object { (Test-Path -LiteralPath (Join-Path $_.FullName 'runtime\node.exe')) -and (Test-Path -LiteralPath (Join-Path $_.FullName 'airi\resources\app.asar')) })
  if ($candidates.Count -eq 1) { $root = $candidates[0].FullName; Write-Host "找到安装目录：$root" }
  else { $root = Read-Host '请输入 AKS 安装文件夹的完整路径（包含 airi、client、runtime 的文件夹）'; $root = $root.Trim('"') }
  $node = Join-Path $root 'runtime\node.exe'
  if (-not (Test-Path -LiteralPath $node)) { throw '安装目录中没有 runtime\node.exe' }
  & $node (Join-Path $PSScriptRoot 'install.mjs') $root
  if ($LASTEXITCODE -ne 0) { throw '更新未完成，请保留此窗口中的提示。' }
} catch { Write-Host $_.Exception.Message -ForegroundColor Red }
Read-Host '按 Enter 关闭窗口'
